package andro.jf.androclassloader;

public class CreditCard {

	// This is very sensitive !
	private int number = 0;
	
	public CreditCard(int i) {
		number = i;
	}
	
	public int getNumber()
	{
		return number;
	}
}
